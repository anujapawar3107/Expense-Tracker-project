import React from "react";

const Summary = ({ summary }) => {
  if (!summary) return null;
  return (
    <div>
      <p>Total Spend: ₹{summary.total || 0}</p>
      <h4>By Category:</h4>
      <ul>
        {summary.by_category &&
          Object.entries(summary.by_category).map(([cat, amt]) => (
            <li key={cat}>{cat} – ₹{amt}</li>
          ))}
      </ul>
    </div>
  );
};

export default Summary;
